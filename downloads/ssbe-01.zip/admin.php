<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>SSBE Admin Panel</title>
	
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
	<script src="http://code.jquery.com/jquery-1.5.js"></script>

	<!--[if IE]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
	<?php include("engine.php"); ?>
	
</head>

<body>
	<br>
	<center><h1>SSBE Admin Panel</h1></center>
	<br>
	<br>
	Back to <a href="index.php">index()</a>.
	<hr>
	<div id="admin"></div>
	<hr>
	
	<b>Post List:</b>
	<br>
	Edit post (id_post): <input id="idpost" type="text" size="10" name="id_post"><span id="msg"></span>

	<form method="POST" action="admin-aux.php">
	Delete post (id_post): <input type="text" size="10" name="id_post"><input type="submit">
						   <input type="hidden" name="hidden" value="deletepost">
	</form>
	<br>
	<div>
	<?php listPosts(); ?>
	</div>
	<hr>
	
	<script>
	$("#admin").load('engine-forms.php #newPostForm');
	
    $('#idpost').keyup(function() {
    	if( $(this).val() == "" )
    		$('#admin').load('engine-forms.php #newPostForm');
    	else
    		$('#admin').load('engine-forms.php #editPostForm', { 'id_post': $(this).val() });
    });
	</script>
	
</body>
</html>